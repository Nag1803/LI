package routines;
public class COMMON {

    /*
     * Writes the console output to log file instead of displaying it on console/server log
     */
    public static void writeConsoleOutput2Log(String log_filename)
    {
            //System. out.println(log_filename.lastIndexOf("/" ));
      String folderpath=StringHandling. LEFT(log_filename, log_filename.lastIndexOf("/" ));
      
      java.io.File folder = new java.io.File(folderpath);
      if (!folder.exists()) {
      if (folder.mkdir()) {
      System. out.println("Directory " +folderpath+" is created!");

      }
      else {
      System. out.println("Failed to create directory at " +folderpath);
      }
      }
      try
      {
      java.io.File file = new java.io.File(log_filename);
      java.io.PrintStream ps = new java.io.PrintStream(new java.io.FileOutputStream(file));
      System.setErr(ps);
      System.setOut(ps);
      }catch(Exception e)
      {
            System. out.println("Log file can not be written" );
      }

    }
}
