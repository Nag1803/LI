package routines;

public class Data_Validation {

        
    public static String cleanName(String name)
    {
    	String value = "";
    	
    	if(name != null)
    	{
    		if(name.isEmpty())
    		{
    			return name;
    		}
    		else
    		{
    			String temp = "";
    			temp = name.trim();
    			
    			value = temp.replaceAll("[^\\(\\)a-zA-Z0-9.-]", "");
    			//value = temp1.replace("'", "");
    	    	return value;
    		}
    	}
    	else
    	{
    		return name;
    	}
    	
    }
    
    public static boolean isNotEmpty(String arg) 
    {
        return arg != null && !arg.isEmpty() ? true : false;
    }

    public static boolean isNotEmptyInteger(Integer arg)
    {
        return arg != null ? true : false;
    }
    
    public static boolean chkColorCode(String code)
    {	
    	if(code != null)
    	{
    		if(code.isEmpty())
    		{
    			return false;
    		}
    		else
    		{   			
    			code = code.replaceAll("#","");
    			return code.matches("^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$");
    		}
    	}
    	else
    	{
    		return false;
    	}
    	
    }
    
    public static boolean validateTaxRate(String tax)
    {
    	if(tax != null)
    	{
    		if(tax.isEmpty())
    		{
    			return true;
    		}
    		else
    		{   			
    			try
    	        {
    	            Integer.parseInt(tax);
    	        }
    	        catch(NumberFormatException ex)
    	        {
    	            return false;
    	        }
    	        return true;    		
    	    }
    	}
    	else
    	{
    		return true;
    	}
    	
    }
    
    public static boolean validateGender(String gender)
    {
    	if(gender != null)
        {
            String temp=gender.trim();
            if(temp.isEmpty())
            {
                return true;
            }
            else
            {                  
                if(gender.equals("F") || gender.equals("M"))
                {
                    return true;
                }
                else
                {
                    return false;                 
                }
            }
        }
        else
        {
            return true;
        }
    	
    }
    
    public static boolean validateEmail(String emaiId) {

    	   if(emaiId != null)
	    	{
	    		if(emaiId.isEmpty())
	    		{
	   			    return true;
	    		}
	    		else
	    		{      			
	    			return emaiId.matches("^[\\-_A-Za-z0-9]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9\\-]*(\\.[A-Za-z]{2,})*(\\.[A-Za-z]{2,})$");
	    	    }
	    	}
	    	else
	    	{
	    		return true;
	    	}
    	 }
    
    public static boolean validateEmail2(String emaiId)    
    {   
        //return emaiId != null ? emaiId.isEmpty() || emaiId.matches("^[_A-Za-z0-9]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]*(\\.[A-Za-z]{2,})$"): false;
        
        if(emaiId != null)
    	{
    		if(emaiId.isEmpty())
    		{
   			    return true;
    		}
    		else
    		{      			
    			emaiId = emaiId.trim();
    			return emaiId.matches("^[_A-Za-z0-9]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]*(\\.[A-Za-z-]{2,})*(\\.[A-Za-z-]{2,})*(\\.[A-Za-z]{2,})$");
    	    }
    	}
    	else
    	{
    		return true;
    	}
    }
    
    public static boolean validateCurrencyCode(String currency)
    {
    	if(currency != null)
    	{
    		if(currency.isEmpty())
    		{
    			return true;
    		}
    		else
    		{      			
    	        if(currency.equals("USD") || currency.equals("JPY"))
    	        {
    	            return true;
    	        }
    	        else
    	        {
        	        return false; 	        	
    	        }
    	    }
    	}
    	else
    	{
    		return true;
    	}
    	
    }
    
    public static boolean validateZipCodeLen(String zip)
    {
    	if(zip != null)
    	{  
    		if(zip.isEmpty())
    		{
    			return true;
    		}
    		else
    		{
    			zip = zip.replace("-", "");
    			//System.out.println(zip);
    			zip = zip.replaceAll("\\s","");
    		//	System.out.println(zip);
   			    if(zip.matches("\\d+"))
    	        {
    	        	if(zip.toString().length() >= 5 && zip.toString().length() <= 9)
    		        {
    		            return true;
    		        }
    		        else
    		        {
    	    	        return false; 	        	
    		        } 
    	        }
    	        else
    	        {
    	        	return false;
    	        }    		
    	     }
	        
    	}
    	else
    	{
    		System.out.println("else.....");
    		return true;
    	}
    	
    }
    
    public static boolean validatePhone(String phoneNumber)
    {  
    	
    	if(phoneNumber != null)
    	{
    		String temp = "";
        	String phonenum = "";
    		temp = phoneNumber.trim();
    		int hyp_index = phoneNumber.indexOf("x");
    		if (hyp_index!= -1)
    		{
    			phonenum = phoneNumber.substring(0, hyp_index);
    	    }
    		else
    		{
    			phonenum = temp;
    		}
    		
    		phoneNumber = phonenum;
        	
        	return phoneNumber  != null ? phoneNumber.isEmpty() || phoneNumber.matches("\\d{10}") ||  phoneNumber.matches("\\d{3}[-\\.\\s]\\d{3}[-\\.\\s]\\d{4}") || phoneNumber.matches("\\(\\d{3}\\)[-\\.\\s]\\d{3}-\\d{4}") || phoneNumber.matches("\\(\\d{3}\\)\\d{3}-\\d{4}") :true;
    	}
    	else
    	{
    		return true;   		
    	}    	
    }
    
    public static boolean validateCountry(String country)
    {
     if(country != null)
     {
      if(country.isEmpty())
      {
       return true;
      }
      else
      {         
             String temp_country = country.trim().toLowerCase();
       if(temp_country.equals("u.s.a") ||temp_country.equals("usa") ||  temp_country.equals("us") || temp_country.equals("united states") || temp_country.equals("japan") || temp_country.equals("jpn") || temp_country.equals("jp"))
             {
                 return true;
             }
             else
             {
                 return false;           
             }
         }
     }
     else
     {
      return true;
     }
     
    }
    
    
}
