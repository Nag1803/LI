package routines;
import java.util.Date;
import java.util.*;
import java.text.DecimalFormat;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class FORMAT {

    /**
       Functions to format data
     */
    public static String getFirstName(String name) {
        if (name == null || (name!=null && name.length()<1)) {
            return ""; //$NON-NLS-1$
        }
        return name.split(" ")[0]; //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    public static String getMiddleName(String name) {
        if (name == null || (name!=null && name.length()<1)) {
            return ""; //$NON-NLS-1$
        }
        if (name.split(" ").length>2)
        	return name.split(" ")[1];
        else return "";
    }
    
    public static String getLastName(String name) {
        if (name == null || (name!=null && name.length()<1)) {
            return ""; //$NON-NLS-1$
        }
        String[] arr=name.split(" ");
        if (arr.length>2)
        	return arr[2];
        else if (arr.length==2) return arr[1];
        else return "";
    }
    
    public static String getPatLastName(String name) {
        if (name == null || (name!=null && name.length()<1)) {
            return ""; //$NON-NLS-1$
        }
        return name.split("\\^")[0]; //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    public static String getPatMiddleName(String name) {
        if (name == null || (name!=null && name.length()<1)) {
            return ""; //$NON-NLS-1$
        }
        if (name.split("\\^").length>2)
        	return name.split("\\^")[2];
        else return "";
    }
    
    public static String getPatFirstName(String name) {
    	if (name == null || (name!=null && name.length()<1)) {
            return ""; //$NON-NLS-1$
        }
        return name.split("\\^")[1]; //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    public static int diffObs(int curr,int initial)
    {
    	//System.out.println("Current= "+curr);
    	//System.out.println("initial= "+initial);
    	if(Relational.ISNULL(curr))
    	{
    		return -1;
    	}
    	else if(Relational.ISNULL(initial))
    	{
    		return -1;
    	}
    	else 
    	{
    		return curr-initial;
    	}
    	
    }
    
    public static String diffObs(float curr,float initial)
    {
    	if (Relational.NOT(Relational.ISNULL(curr)) && Relational.NOT(Relational.ISNULL(initial)))
     		{
    		Float dif;
    		dif=curr-initial;

            DecimalFormat df = new DecimalFormat("###.#");
            return df.format(dif);
    		}
        else
    		return "-1.0";
    }
    
    public static String formatDateWithTZ(Date dt)
    {
    	try
    	{
    	String datePart=TalendDate.formatDate("yyyy-MM-dd", dt);
    	String timePart=TalendDate.formatDate("HH:mm:ss", dt);
    	return datePart+"T"+timePart+".00-06:00";
    	}
    	catch(Exception e)
    	
    	{
    		return null;
    	}
    }
    public static Date epoch2Date(Long epochDate){
        try{
         return new Date(epochDate);
        }catch(Exception e)
        {
         return null;
        }
       }
    	
    
    public static String getSUB(String name) {
        if (name == null || (name!=null && name.length()<1)) {
            return ""; //$NON-NLS-1$
        }
        return name.substring(0,3); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    public static String getSUB2(String name) {
    	  ArrayList<String> parent = new ArrayList<String>();
    	  ArrayList<String> childs = new ArrayList<String>();
    	  String[] strarray1 = null;
    	  StringBuffer result = new StringBuffer();
    	  
    	  if (name == null || (name.length()<1)) {
              return "NA"; 
          }
    	  else{
    		  String[] strarray = name.split(";");
    		  Collections.addAll(parent,strarray);
    		  for (int i = 0; i < parent.size(); i++)
        	  {
        	   Collections.addAll(childs,parent.get(i).split(","));
        	  }
    		  strarray1 = childs.toArray(new String[0]);
    		  for (int i = 0; i < childs.size(); i++)
        	  {
        	   if(strarray1[i].startsWith("CN="))
        	   {
        		   result.append(strarray1[i].substring(3)).append(",");
        	   }
        	  } 
    		  String mynewstring = result.toString();
    		  mynewstring = mynewstring.substring(0, mynewstring.length()-1);
    		  return mynewstring ;
    	  } 	   
    }
      
}
