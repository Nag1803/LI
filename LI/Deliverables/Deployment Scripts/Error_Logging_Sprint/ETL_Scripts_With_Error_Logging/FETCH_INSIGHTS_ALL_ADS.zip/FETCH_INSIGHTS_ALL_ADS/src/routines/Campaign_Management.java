package routines;

/*import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.net.*;

import com.microsoft.bingads.*;*/
import com.microsoft.bingads.v10.bulk.entities.*;
import com.microsoft.bingads.v10.bulk.*;
/*import com.microsoft.bingads.v10.bulk.AdApiError;
import com.microsoft.bingads.v10.bulk.AdApiFaultDetail_Exception;
import com.microsoft.bingads.v10.bulk.ApiFaultDetail_Exception;
import com.microsoft.bingads.v10.bulk.BatchError;
import com.microsoft.bingads.v10.bulk.OperationError;*/
import com.microsoft.bingads.v10.campaignmanagement.*;

 
public class Campaign_Management {

	   BulkEntityIterable bulkEntities = null;
       
	   public static void outputBulkCampaigns(Iterable<BulkCampaign> bulkEntities){
	          for (BulkCampaign entity : bulkEntities){
	              System.out.println("\nBulkCampaign: \n");
	              System.out.println(String.format("AccountId: %s", entity.getAccountId()));
	              System.out.println(String.format("ClientId: %s", entity.getClientId()));
	              if(entity.getLastModifiedTime() != null){
	                  System.out.println(String.format("LastModifiedTime: %s", entity.getLastModifiedTime().getTime()));
	              }

	              /*outputBulkPerformanceData(entity.getPerformanceData());
	              outputBulkQualityScoreData(entity.getQualityScoreData());*/

	              // Output the Campaign Management Campaign Object
	              outputCampaign(entity.getCampaign());

	              if(entity.hasErrors()){
	                  outputBulkErrors(entity.getErrors());
	              }
	          }
	      }

	   public static void outputCampaign(Campaign campaign){
	          if (campaign != null) {
	              System.out.println(String.format("BudgetType: %s", campaign.getBudgetType()));
	              System.out.println(String.format("CampaignType: %s", campaign.getCampaignType()));
	              System.out.println(String.format("DailyBudget: %s", campaign.getDailyBudget()));
	              System.out.println(String.format("Description: %s", campaign.getDescription()));
	              System.out.println(String.format("Id: %s", campaign.getId()));
	              System.out.println(String.format("MonthlyBudget: %s", campaign.getMonthlyBudget()));
	              System.out.println(String.format("Name: %s", campaign.getName()));
	              System.out.println(String.format("NativeBidAdjustment: %s", campaign.getNativeBidAdjustment()));
	              System.out.println("Settings: ");
	              if (campaign.getSettings() != null)
	              {
	                  for (Setting setting : campaign.getSettings().getSettings())
	                  {
	                      if (setting instanceof ShoppingSetting)
	                      {
	                          System.out.println("ShoppingSetting: ");
	                          System.out.println(String.format("Priority: %s", ((ShoppingSetting)setting).getPriority()));
	                          System.out.println(String.format("SalesCountryCode: %s", ((ShoppingSetting)setting).getSalesCountryCode()));
	                          System.out.println(String.format("StoreId: %s", ((ShoppingSetting)setting).getStoreId()));
	                      }
	                  }
	              }
	              System.out.println(String.format("Status: %s", campaign.getStatus()));
	              System.out.println(String.format("TimeZone: %s", campaign.getTimeZone()));
	          }
	      }

	   public static void outputBulkPerformanceData(PerformanceData performanceData){
	          if (performanceData != null)
	          {
	              System.out.println("PerformanceData: ");
	              System.out.println(String.format("AverageCostPerClick: %s", performanceData.getAverageCostPerClick()));
	              System.out.println(String.format("AverageCostPerThousandImpressions: %s", performanceData.getAverageCostPerThousandImpressions()));
	              System.out.println(String.format("AveragePosition: %s", performanceData.getAveragePosition()));
	              System.out.println(String.format("Clicks: %s", performanceData.getClicks()));
	              System.out.println(String.format("ClickThroughRate: %s", performanceData.getClickThroughRate()));
	              System.out.println(String.format("Conversions: %s", performanceData.getConversions()));
	              System.out.println(String.format("CostPerConversion: %s", performanceData.getCostPerConversion()));
	              System.out.println(String.format("Impressions: %s", performanceData.getImpressions()));
	              System.out.println(String.format("Spend: %s", performanceData.getSpend()));
	          }
	      }

	   public static void outputBulkQualityScoreData(QualityScoreData qualityScoreData){
	          if (qualityScoreData != null)
	          {
	              System.out.println("QualityScoreData: ");
	              System.out.println(String.format("KeywordRelevance: %s", qualityScoreData.getKeywordRelevance()));
	              System.out.println(String.format("LandingPageRelevance: %s", qualityScoreData.getLandingPageRelevance()));
	              System.out.println(String.format("LandingPageUserExperience: %s", qualityScoreData.getLandingPageUserExperience()));
	              System.out.println(String.format("QualityScore: %s", qualityScoreData.getQualityScore()));
	          }
	      }
	  
	   public static void outputBulkErrors(Iterable<BulkError> errors){
	          for (BulkError error : errors){
	              System.out.println(String.format("Error: %s", error.getError()));
	              System.out.println(String.format("Number: %s\n", error.getNumber()));
	              if(error.getEditorialReasonCode() != null){
	                  System.out.println(String.format("EditorialTerm: %s\n", error.getEditorialTerm()));
	                  System.out.println(String.format("EditorialReasonCode: %s\n", error.getEditorialReasonCode()));
	                  System.out.println(String.format("EditorialLocation: %s\n", error.getEditorialLocation()));
	                  System.out.println(String.format("PublisherCountries: %s\n", error.getPublisherCountries()));
	              }
	          }
	      }

	   public static void outputBulkAdGroups(Iterable<BulkAdGroup> bulkEntities){
	          for (BulkAdGroup entity : bulkEntities){
	              System.out.println("\nBulkAdGroup: \n");
	              System.out.println(String.format("CampaignId: %s", entity.getCampaignId()));
	              System.out.println(String.format("CampaignName: %s", entity.getCampaignName()));
	              System.out.println(String.format("ClientId: %s", entity.getClientId()));
	              System.out.println(String.format("IsExpired: %s", entity.getIsExpired()));
	              if(entity.getLastModifiedTime() != null){
	                  System.out.println(String.format("LastModifiedTime: %s", entity.getLastModifiedTime().getTime()));
	              }

	             // outputBulkPerformanceData(entity.getPerformanceData());
	              //outputBulkQualityScoreData(entity.getQualityScoreData());

	              // Output the Campaign Management AdGroup Object
	              outputAdGroup(entity.getAdGroup());

	              if(entity.hasErrors()){
	                  outputBulkErrors(entity.getErrors());
	              }
	          }
	      }

	   public static void outputAdGroup(AdGroup adGroup){
	          if (adGroup != null) {
	              if (adGroup.getAdDistribution() != null)
	              {
	                  System.out.println("AdDistribution: ");
	                  for (AdDistribution distribution : adGroup.getAdDistribution())
	                  {
	                      System.out.println(String.format("\t%s", distribution));
	                  }
	              }
	              System.out.println(String.format("AdRotation: %s", 
	                      adGroup.getAdRotation() != null ? adGroup.getAdRotation().getType() : null));
	              System.out.println(String.format("BiddingModel: %s", adGroup.getBiddingModel()));
	              System.out.println(String.format("ContentMatchBid: %s", 
	                      adGroup.getContentMatchBid() != null ? adGroup.getContentMatchBid().getAmount() : null));
	              if (adGroup.getEndDate() != null)
	              {
	                  System.out.println(String.format("EndDate: %s/%s/%s",
	                  adGroup.getEndDate().getMonth(),
	                  adGroup.getEndDate().getDay(),
	                  adGroup.getEndDate().getYear()));
	              }
	              System.out.println(String.format("Id: %s", adGroup.getId()));
	              System.out.println(String.format("Language: %s", adGroup.getLanguage()));
	              System.out.println(String.format("Name: %s", adGroup.getName()));
	              System.out.println(String.format("NativeBidAdjustment: %s", adGroup.getNativeBidAdjustment()));
	              System.out.println(String.format("Network: %s", adGroup.getNetwork()));
	              System.out.println(String.format("PricingModel: %s", adGroup.getPricingModel()));
	              System.out.println(String.format("SearchBid: %s", 
	                      adGroup.getSearchBid() != null ? adGroup.getSearchBid().getAmount() : null));
	              if (adGroup.getStartDate() != null)
	              {
	                  System.out.println(String.format("StartDate: %s/%s/%s",
	                  adGroup.getStartDate().getMonth(),
	                  adGroup.getStartDate().getDay(),
	                  adGroup.getStartDate().getYear()));
	              }
	              System.out.println(String.format("Status: %s", adGroup.getStatus()));
	          }
	      }

	   public static void outputBulkTextAds(Iterable<BulkTextAd> bulkEntities){
	          for (BulkTextAd entity : bulkEntities){
	              System.out.println("BulkTextAd: \n");
	              System.out.println(String.format("TextAd DisplayUrl: %s\nTextAd Id: %s\n", 
	                      entity.getAd().getDisplayUrl(),
	                      entity.getAd().getId()));

	              if(entity.hasErrors()){
	                  outputBulkErrors(entity.getErrors());
	              }
	          }
	      }

	   public static void outputBulkKeywords(Iterable<BulkKeyword> bulkEntities){
	          for (BulkKeyword entity : bulkEntities){
	              System.out.println("BulkKeyword: \n");
	              System.out.println(String.format("Keyword Text: %s\nKeyword Id: %s\n", 
	                      entity.getKeyword().getText(),
	                      entity.getKeyword().getId()));

	              if(entity.hasErrors()){
	                  outputBulkErrors(entity.getErrors());
	              }
	          }
	      }
}
