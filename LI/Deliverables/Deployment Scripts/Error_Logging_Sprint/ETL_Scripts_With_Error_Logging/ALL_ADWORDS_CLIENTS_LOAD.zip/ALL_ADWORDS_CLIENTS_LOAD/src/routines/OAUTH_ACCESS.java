package routines;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
 import org.openqa.selenium.support.ui.ExpectedConditions;
 import org.openqa.selenium.support.ui.WebDriverWait;
 import com.microsoft.bingads.OAuthDesktopMobileAuthCodeGrant;
 import com.microsoft.bingads.OAuthWebAuthCodeGrant;
 import com.microsoft.bingads.internal.OAuthWithAuthorizationCode;
 import com.microsoft.bingads.AuthorizationData;
 import com.microsoft.bingads.OAuthTokens;
 import java.net.*;
 import java.net.MalformedURLException;
 //import org.apache.http.conn.h;
 
public class OAUTH_ACCESS
{
	//AuthorizationData authorizationData;
	public static AuthorizationData access_grant(String UserName,String Password,AuthorizationData authorizationData,String ClientId,String DevToken,String PHANTOM_JS_PATH,String access_method,String redirect_uri,String ClientSecret)
	{
	try
	{
		OAuthWithAuthorizationCode oAuthCodeGrant=null;
		System.setProperty( "phantomjs.binary.path", PHANTOM_JS_PATH );
		 WebDriver driver = new PhantomJSDriver();
		if (access_method.equalsIgnoreCase("web"))
		{
	     oAuthCodeGrant=new OAuthWebAuthCodeGrant(ClientId, ClientSecret, new URL(redirect_uri));    
		}
		else
		{
			 oAuthCodeGrant = new OAuthDesktopMobileAuthCodeGrant(ClientId);
		}
		driver.get(oAuthCodeGrant.getAuthorizationEndpoint().toString()); 
			
		
        
	    String loginUrl = driver.getCurrentUrl();
	    System.out.println("endpoint url-------"+loginUrl); 
	 
	    WebElement userId= driver.findElement(By.name("loginfmt"));
	    userId.sendKeys(UserName);
			    System.out.println("USER NAME"+userId.getText());
			    
			    WebElement passWd = driver.findElement(By.name("passwd"));
			    passWd.sendKeys(Password);
			    //System.out.println("PASS WORD"+passWd.getText());
	    
	    
	    WebElement signIn=(new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.id("idSIButton9")));
		signIn.click();	
		
	    System.out.println("Page title is: " + driver.getTitle());    
	    WebElement consentYes=(new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.id("idBtn_Accept")));
	    consentYes.click();
	    
	    String in_url=driver.getCurrentUrl();
	    
	    URL url = new URL(in_url);
	    
	    System.out.println("url------"+driver.getCurrentUrl());
	     OAuthTokens tokens=oAuthCodeGrant.requestAccessAndRefreshTokens(url);
		 authorizationData = new AuthorizationData();
	        	
	        	//System.out.println("ACC "+context.BING_ACCOUNT_ID);
	       
	            authorizationData.setDeveloperToken(DevToken);
	            //authorizationData.setCustomerId(CustomerId);
	           // authorizationData.setAccountId(AccountId);
	             authorizationData.setAuthentication(oAuthCodeGrant);
	            System.out.println("Trying to validate...");
	            authorizationData.validate();
	              System.out.println("Executed validate method...");
	              driver.quit();
	            
	}
	catch(MalformedURLException e)
	{
		System.out.println("Error Message: "+e.getMessage());
	}
	  return authorizationData;
	}
	}
    
