package routines;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
 import org.openqa.selenium.support.ui.ExpectedConditions;
 import org.openqa.selenium.support.ui.WebDriverWait;
 import com.microsoft.bingads.OAuthDesktopMobileAuthCodeGrant;
 
 
public class Copy_of_OAUTH_ACCESS {
    public String getUrl(String UserName,String Password,String  phantom_js_path, OAuthDesktopMobileAuthCodeGrant oAuthDesktopMobileAuthCodeGrant)
    {
    	
    	String out_url;
	System.setProperty( "phantomjs.binary.path", phantom_js_path );
    WebDriver driver = new PhantomJSDriver();
	driver.get(oAuthDesktopMobileAuthCodeGrant.getAuthorizationEndpoint().toString()); 
	
    String loginUrl = driver.getCurrentUrl();
    System.out.println("endpoint url from oAuth object-------"+loginUrl); 
 
    WebElement userId= driver.findElement(By.name("loginfmt"));
    userId.sendKeys(UserName);
    WebElement passWd = driver.findElement(By.name("passwd"));
	passWd.sendKeys(Password);
	 	
    WebElement signIn=(new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.id("idSIButton9")));
	signIn.click();	
	
    System.out.println("Page title after authentication is: " + driver.getTitle());    
    WebElement consentYes=(new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.id("idBtn_Accept")));
    consentYes.click();
    out_url=driver.getCurrentUrl();
    driver.quit();
        
    return out_url;
    }
}
