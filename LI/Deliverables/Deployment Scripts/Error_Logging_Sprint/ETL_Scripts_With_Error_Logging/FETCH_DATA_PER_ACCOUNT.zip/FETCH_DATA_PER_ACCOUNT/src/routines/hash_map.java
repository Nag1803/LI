package routines;

import java.util.HashMap;;

public class hash_map {

	public static HashMap<String, String> GlobalVariables = new HashMap<String, String>();
    
    public static void add(String key,String value)
   {
     GlobalVariables.put(key, value);
   }
   
    public static String get(String key)
   {
         String value= "";
          if(key != null)
               {
                String var_temp = GlobalVariables.get(key);
                value = Relational.ISNULL(var_temp)?"":var_temp;
               
               }
          return value;
   }
}
